# Size indicates importance

---

##### Fix/Enhance proxy enabler

---

#### Add search music

---

#### Add switching scheme in the bookmarks section

---

### Make a wizard setup action

---

### Utilize url dispatcher

---

#### Combine kids indexers (greek-movies.com + gamatotv4.com)

---

### Allow precaching of certain sections of the addon

---

### Build mirror script

---

#### Build setup script
